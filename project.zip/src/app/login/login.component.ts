// login.component.ts

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { createClient } from '@supabase/supabase-js';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {

  supabase = createClient('https://lqviihvmwdkabqlpecxh.supabase.co','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxxdmlpaHZtd2RrYWJxbHBlY3hoIiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTkzMzgxNDAsImV4cCI6MjAxNDkxNDE0MH0.970stIqUsgdhPxejzbb-6R39pDOAx3J4rIGWz_c6ZAM')
  constructor(private router: Router){}
  loginForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', Validators.required),
    });
  

  // onSubmit() {
  //   if (this.loginForm.valid) {
  //     const formData = this.loginForm.value;
  //     // You can now use formData and send it to your service or perform any other actions.
  //     console.log(formData);
  //   }
  // }
  async onSubmit() {
    if (this.loginForm.valid) {

      const { data, error } = await this.supabase.auth.signInWithPassword({
        email: this.loginForm.value.email as string,
        password: this.loginForm.value.password as string,
      })      // You can now use formData and send it to your service or perform any other actions.
      if (error) {
        console.error('Sign-up error:', error.message);
      } else {
        console.log('Sign-up successful:', data);
        // Perform any additional actions after successful sign-up
        this.router.navigate(['/mainpage']);
      }
    }
    
  }
}
// async login() {
//   const { email, password } = this.loginForm.value;

// try {
//   // Sign in using Supabase
//   const { data, error } = await this.supabase.auth.signInWithPassword({
//     email: this.loginForm.value.email!,
//     password: this.loginForm.value.password!,
//   });

//   if (error) {
//     // Handle login errors
//     console.error('Login error:', error);
//     // Perform error handling (e.g., display an error message to the user)
//   } else if (data) {
//     // Fetch user data from the Supabase table based on the provided email
//     const { data, error: fetchError } = await this.supabase
//       .from('usertable')
//       .select('username')
//       .eq('email', email)
//       .single();

     
//     if (fetchError) {
//       // Handle fetch error
//       console.error('Fetch user data error:', fetchError);
//       // Perform error handling (e.g., display an error message to the user)
//     } else if (data) {
//       const { username } = data;
//       // Store the username in local storage
//       localStorage.setItem('username', username);
//       console.log('Username stored in local storage:', username);
     
//       // Redirect to a different route or perform other actions upon successful login
//       this.router.navigate(['/dashboard'], { queryParams: { username: username } }); // Change '/dashboard' to your desired route
//     }
//   }
// } catch (error) {
//   // Handle other potential errors (e.g., network issues)
//   console.error('Unexpected error:', error);
//   // Perform error handling (e.g., display an error message to the user)
// }
// }

  
