// import { Component, OnInit } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { TenantService } from '../tenant.service';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// @Component({
//   selector: 'app-tenant-list',
//   templateUrl: './tenant-list.component.html',
//   styleUrls: ['./tenant-list.component.css'],
// })
// export class TenantListComponent implements OnInit {
//   tenants: any[] = []; // Define the tenants array to store data from the API.
//   createUserForm: FormGroup;

//   constructor(private tenantData:TenantService,private formBuilder: FormBuilder) {
    
//     this.createUserForm = this.formBuilder.group({
//       id: [0], // ID field (can be null for new users)
//       name: ['', Validators.required], // Name field (required)
//       lastName: ['', Validators.required], // Last Name field (required)
//       email: ['', [Validators.required, Validators.email]], // Email field (required and email format)
//       department: [''], // Department field (optional)
//     });
    
//   }

//   ngOnInit() {
//     this.fetchTenants();
//   }

//   fetchTenants() {
//     this.tenantData.getAllTenants().subscribe((data: any)=>{
//       this.tenants=data;
//     })
//   }
//   // onSubmit() {
//   //   // Implement the logic to handle the form submission here.
//   //   if (this.createUserForm.valid) {
//   //     const formData = this.createUserForm.value;
//   //     // You can send the formData to an API or process it as needed.
//   //   }
//   // }
//   editTenant(tenant: any) {
//     // Implement edit functionality here.
//     // You can navigate to an edit page or show a modal to edit the tenant.
//   }

//   deleteTenant(tenantId: number) {
//     // Implement delete functionality here.
//     // You can show a confirmation modal and delete the tenant via API.
//   }

//   createUser() { 
//     console.log("hhh");
//     if (this.createUserForm.valid) {
//     const formData = this.createUserForm.value;
//     // console.log(formData)
//      this.tenantData.createTenants(formData).subscribe((data)=>{
//       //window.location.reload();
//       // setTimeout(() => {
//       //   window.location.reload();
//       // }, 1000);
//       this.tenants.push(data);

//       // Reset the form or clear it after successful submission.
//       this.createUserForm.reset();
//      });
//   }
  
// }


// }

import { Component, OnInit } from '@angular/core';
import { TenantService } from '../tenant.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-tenant-list',
  templateUrl: './tenant-list.component.html',
  styleUrls: ['./tenant-list.component.css'],
})
export class TenantListComponent {
  tenants: any[] = [];
  createUserForm: FormGroup;
  editUserForm: FormGroup;

  constructor(private tenantData: TenantService, private formBuilder: FormBuilder) {
    this.createUserForm = this.formBuilder.group({
      id: [0],
      name: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      department: [''],
    });

    // Initialize Edit User Form
    this.editUserForm = this.formBuilder.group({
      id: [0],
      name: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      department: [''],
    });
  }

  ngOnInit() {
    this.fetchTenants();
  }

  fetchTenants() {
    this.tenantData.getAllTenants().subscribe((data: any) => {
      this.tenants = data;
    });
  }

  createUser() {
    if (this.createUserForm.valid) {
      const formData = this.createUserForm.value;
      this.tenantData.createTenants(formData).subscribe((data) => {
        this.tenants.push(data);
        this.createUserForm.reset();
      });
    }
  }

  editTenant(tenant: any) {
    // Implement the logic to populate the editUserForm with tenant data for editing.
    this.editUserForm.patchValue({
      id: tenant.id,
      name: tenant.name,
      lastName: tenant.lastName,
      email: tenant.email,
      department: tenant.department,
    });
  }
  setFormValues(tenant: any) {
    this.editUserForm.setValue({
      id: tenant.id,
      name: tenant.name,
      lastName: tenant.lastName,
      email: tenant.email,
      department: tenant.department
    });
  }
  updateUser() {
    
    //console.log("jjjjj");
    
      const formData = this.editUserForm.value;
      this.tenantData.updateTenant(formData).subscribe(() => {
        
      });
    
  }

  deleteTenant(id: number) {
    if (confirm('Are you sure you want to delete this tenant?')) {
      this.tenantData.deleteTenant(id).subscribe(() => {
        // Remove the deleted tenant from the tenants array.
        
      });
    }
  }
  

  // deleteTenant(tenantId: number) {
  //   // Implement delete functionality here.
  //   // You can show a confirmation modal and delete the tenant via API.
  //   this.tenantData.deleteTenant(tenantId).subscribe(() => {
  //     // Remove the deleted tenant from the tenants array.
  //     this.tenants = this.tenants.filter((tenant) => tenant.id !== tenantId);
  //   });
  // }
}
