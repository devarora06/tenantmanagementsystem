// signup.component.ts

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { createClient } from '@supabase/supabase-js';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css'],
})
export class SignupComponent {
  
supabase = createClient('https://lqviihvmwdkabqlpecxh.supabase.co','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxxdmlpaHZtd2RrYWJxbHBlY3hoIiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTkzMzgxNDAsImV4cCI6MjAxNDkxNDE0MH0.970stIqUsgdhPxejzbb-6R39pDOAx3J4rIGWz_c6ZAM')
  constructor(private router: Router){}
    signupForm = new FormGroup({
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      department: new FormControl(''),
      tenantName: new FormControl('', Validators.required),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    });
  

  async onSubmit() {
    if (this.signupForm.valid) {

      const { data, error } = await this.supabase.auth.signUp({
        email: this.signupForm.value.email as string,
        password: this.signupForm.value.password as string,
      })      // You can now use formData and send it to your service or perform any other actions.
      if (error) {
        console.error('Sign-up error:', error.message);
      } else {
        console.log('Sign-up successful:', data);
        // Perform any additional actions after successful sign-up
        this.router.navigate(['/login']);
      }
    }
    
  }
}
